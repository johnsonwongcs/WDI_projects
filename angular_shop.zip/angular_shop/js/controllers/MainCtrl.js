app.controller('MainCtrl',MainCtrl);

function MainCtrl(){
	
}